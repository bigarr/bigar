<?php
$koneksi = new mysqli("localhost", "root", "", "akarbumi");
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

// Ambil semua kategori untuk menu
$kategoriResult = $koneksi->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");

// Tangkap parameter kategori dari URL, misal ?kategori=3
$kategori_id = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;

// Query produk sesuai kategori, jika kategori_id=0 maka tampilkan semua produk
if ($kategori_id > 0) {
  $sql = "SELECT * FROM produk WHERE kategori_id = $kategori_id";
} else {
  $sql = "SELECT * FROM produk";
}

$result = $koneksi->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Produk Akar Bumi</title>
  <style>
    /* Styles singkat untuk menu kategori dan produk */
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f9f9f9;
      color: #333;
    }

    .kategori-menu {
      background: #44732c;
      padding: 10px 40px;
      display: flex;
      gap: 15px;
      overflow-x: auto;
    }

    .kategori-menu a {
      color: white;
      font-weight: 600;
      padding: 8px 15px;
      border-radius: 5px;
      text-decoration: none;
      white-space: nowrap;
      background: rgba(255, 255, 255, 0.15);
      transition: background-color 0.3s;
    }

    .kategori-menu a:hover,
    .kategori-menu a.active {
      background: white;
      color: #44732c;
    }

    .products {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      padding: 40px;
    }

    .product-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.2s;
      display: block;
    }

    .product-card:hover {
      transform: scale(1.02);
    }

    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .product-info {
      padding: 15px;
    }

    .product-info h3 {
      margin: 0 0 10px;
      font-size: 1.2rem;
    }

    .product-info p {
      margin: 0;
      color: #555;
    }

    .harga-produk {
      color: red;
      font-weight: 450;
      font-size: 17px;
    }
  </style>
</head>

<body>

  <nav class="kategori-menu">
    <a href="produk.php" class="<?= $kategori_id == 0 ? 'active' : '' ?>">Semua Kategori</a>
    <?php while ($kat = $kategoriResult->fetch_assoc()): ?>
      <a href="produk.php?kategori=<?= $kat['id'] ?>" class="<?= $kategori_id == $kat['id'] ? 'active' : '' ?>">
        <?= htmlspecialchars($kat['nama_kategori']) ?>
      </a>
    <?php endwhile; ?>
  </nav>

  <section class="products">
    <?php if ($result->num_rows > 0): ?>
      <?php while ($produk = $result->fetch_assoc()): ?>
        <a href="detail_produk.php?id=<?= $produk['id'] ?>" class="product-card">
          <img src="<?= htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>">
          <div class="product-info">
            <h3><?= htmlspecialchars($produk['nama']) ?></h3>
            <p class="harga-produk">Rp<?= number_format($produk['harga'], 0, ',', '.') ?></p>
          </div>
        </a>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="padding: 20px;">Tidak ada produk di kategori ini.</p>
    <?php endif; ?>
  </section>

</body>

</html>
