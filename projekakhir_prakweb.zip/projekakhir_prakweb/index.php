<?php
$koneksi = new mysqli("localhost", "root", "", "akarbumi");
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

$sql = "SELECT * FROM produk";
$result = $koneksi->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Akar Bumi</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f9f9f9;
      color: #333;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    .nav-container {
      display: flex;
      align-items: center;
      gap: 30px;
    }

    .nav-links {
      display: flex;
      gap: 10px;
    }

    .nav-links a {
      color: rgb(68, 115, 44);
      font-weight: 600;
      font-size: large;
    }


    nav {
      position: sticky;
      top: 0;
      z-index: 1000;
      background-color: rgb(255, 255, 255);
      display: flex;
      justify-content: first baseline;
      padding: 10px 0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    nav a {
      color: white;
      margin: 0 15px;
      font-weight: bold;
    }

    .hutan {
      position: relative;
      height: 400px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      max-width: 1418px;
      margin: 0 auto;
      border-radius: 10px;
    }

    .hutan-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: url('hutan.jpg') center/cover no-repeat;
      filter: blur(3px);
      z-index: 1;
    }

    .hutan-text {
      position: relative;
      z-index: 2;
      color: white;
      font-size: 48px;
      text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.6);
      text-align: center;
      font-family: 'Courier New', Courier, monospace;
      font-weight: 500;
    }

    .products {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      padding: 40px;
    }

    .product-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.2s;
      display: block;
    }

    .product-card:hover {
      transform: scale(1.02);
    }

    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .product-info {
      padding: 15px;
    }

    .product-info h3 {
      margin: 0 0 10px;
      font-size: 1.2rem;
    }

    .product-info p {
      margin: 0;
      color: #555;
    }

    .product-info .harga-produk {
      color: red;
      font-weight: 450;
      font-size: 17px;
    }


    footer {
      background: rgb(68, 115, 44);
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }
  </style>
</head>

<body>


  <nav>
    <div class="nav-container">
      <img src="logo.png" alt="Logo" style="height: 50px; vertical-align: middle; padding-left: 60px;">

      <div class="nav-links">
        <a href="#" class="active">Beranda</a>
        <a href="#">Produk</a>
        <a href="#">Tentang Kami</a>
        <a href="#">Kontak</a>
      </div>
    </div>
  </nav>


  <div class="hutan">
    <div class="hutan-bg"></div>
    <div class="hutan-text">Dari Akar, Untuk Bumi!</div>
  </div>


  <section class="products">
    <?php if ($result->num_rows > 0): ?>
      <?php while ($produk = $result->fetch_assoc()): ?>
        <a href="detail_produk.php?id=<?= $produk['id'] ?>" class="product-card">
          <img src="<?= htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>">
          <div class="product-info">
            <h3><?= htmlspecialchars($produk['nama']) ?></h3>
            <p class="harga-produk">Rp<?= number_format($produk['harga'], 0, ',', '.') ?></p>
          </div>
        </a>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="padding: 20px;">Tidak ada produk yang tersedia.</p>
    <?php endif; ?>
  </section>

  <footer>
    &copy; 2025 Akar Bumi. Semua hak dilindungi.
  </footer>

</body>

</html>