<?php
$koneksi = new mysqli("localhost", "root", "", "akarbumi");
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT * FROM produk WHERE id = $id";
$result = $koneksi->query($sql);

if ($result->num_rows === 0) {
  echo "<h2>Produk tidak ditemukan.</h2>";
  exit;
}

$produk = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($produk['nama']) ?> - Akar Bumi</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f9f9f9;
      color: #333;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    .nav-container {
      display: flex;
      align-items: center;
      gap: 30px;
    }

    .nav-links {
      display: flex;
      gap: 10px;
    }

    .nav-links a {
      color: #388e3c;
      font-weight: 600;
      font-size: large;
    }

    nav {
      background-color: rgb(255, 255, 255);
      display: flex;
      justify-content: first baseline;
      padding: 10px 0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .layout {
      display: flex;
      flex-wrap: wrap;
      align-items: flex-start;
      justify-content: center;
      gap: 40px;
      padding: 40px;
    }

    .image-wrapper {
      flex: 1;
      max-width: 600px;
    }

    .image-wrapper img {
      width: 100%;
      border-radius: 10px;
      object-fit: cover;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .container {
      flex: 1;
      max-width: 600px;
      padding: 20px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .info h2 {
      margin-top: 0;
      font-weight:500;
    }

    .info p {
      margin: 10px 0;
    }

    .harga-produk {
      color: red;
      font-weight: 500;
      font-size: 23px;
    }

    .garis-harga {
      border: none;
      border-top: 1px solid grey;
      margin: 15px 0 15px 0;
      width: 100%;
    }


    form {
      margin-top: 20px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      font-weight: 600;
    }

    input[type="number"] {
      width: 80px;
      padding: 8px;
      font-size: 1rem;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button {
      padding: 10px 20px;
      background-color: rgb(68, 115, 44);
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
    }

    button:hover {
      background-color:rgb(68, 115, 44);
    }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      color:rgb(68, 115, 44);
      font-weight: bold;
      text-decoration: none;
    }

    footer {
      background:rgb(68, 115, 44);
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }
  </style>
</head>

<body>

  <nav>
    <div class="nav-container">
      <img src="logo.png" alt="Logo" style="height: 50px; vertical-align: middle; padding-left: 60px;">
      <div class="nav-links">
        <a href="index.php">Beranda</a>
        <a href="#">Produk</a>
        <a href="#">Tentang Kami</a>
        <a href="#">Kontak</a>
      </div>
    </div>
  </nav>

  <div class="layout">
    <div class="image-wrapper">
      <img src="<?= htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>" />
    </div>

    <div class="container">
      <div class="info">
        <h2><?= htmlspecialchars($produk['nama']) ?></h2>
        <p><strong></strong><span class="harga-produk">Rp<?= number_format($produk['harga'], 0, ',', '.') ?></span></p>
        <hr class="garis-harga" />
        <p><?= nl2br(htmlspecialchars($produk['deskripsi'])) ?></p>

        <form action="proses_beli.php" method="POST">
          <input type="hidden" name="produk_id" value="<?= $produk['id'] ?>">
          <label for="jumlah">Jumlah:</label>
          <input type="number" name="jumlah" id="jumlah" value="1" min="1" required>
          <br>
          <button type="submit">Beli Sekarang</button>
        </form>


        <a href="index.php" class="back-link">← Kembali ke Beranda</a>
      </div>
    </div>
  </div>

  <footer>
    &copy; 2025 Akar Bumi. Semua hak dilindungi.
  </footer>

</body>

</html>